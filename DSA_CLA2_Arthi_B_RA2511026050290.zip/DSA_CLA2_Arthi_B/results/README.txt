Run `python src/main.py` from the project root to generate experiment_results.json here.
