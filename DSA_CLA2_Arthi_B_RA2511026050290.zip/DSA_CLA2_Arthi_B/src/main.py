"""Student Record Search System: BST, AVL Tree, and Hashing (Linear Probing)."""
from dataclasses import dataclass
from pathlib import Path
import csv
import random
import json

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "students.csv"
RESULTS_DIR = ROOT / "results"

@dataclass
class Student:
    register_no: int
    name: str
    department: str
    year: int
    cgpa: float

def load_students():
    records = []
    with DATA_FILE.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            records.append(Student(int(row["register_no"]), row["name"],
                                   row["department"], int(row["year"]), float(row["cgpa"])))
    return records

class BSTNode:
    def __init__(self, student):
        self.student, self.left, self.right = student, None, None

class BST:
    def __init__(self):
        self.root = None

    def insert(self, student):
        if self.root is None:
            self.root = BSTNode(student); return
        cur = self.root
        while True:
            if student.register_no < cur.student.register_no:
                if cur.left is None:
                    cur.left = BSTNode(student); return
                cur = cur.left
            elif student.register_no > cur.student.register_no:
                if cur.right is None:
                    cur.right = BSTNode(student); return
                cur = cur.right
            else:
                raise ValueError("Duplicate register number")

    def search(self, key):
        cur, comparisons = self.root, 0
        while cur:
            comparisons += 1
            if key == cur.student.register_no: return cur.student, comparisons
            cur = cur.left if key < cur.student.register_no else cur.right
        return None, comparisons

    def height(self):
        def h(node):
            if node is None: return -1  # height measured in edges; empty tree = -1
            return 1 + max(h(node.left), h(node.right))
        return h(self.root)

    def inorder(self):
        out = []
        def walk(n):
            if n:
                walk(n.left); out.append(n.student.register_no); walk(n.right)
        walk(self.root); return out

    def preorder(self):
        out = []
        def walk(n):
            if n:
                out.append(n.student.register_no); walk(n.left); walk(n.right)
        walk(self.root); return out

    def postorder(self):
        out = []
        def walk(n):
            if n:
                walk(n.left); walk(n.right); out.append(n.student.register_no)
        walk(self.root); return out

class AVLNode:
    def __init__(self, student):
        self.student, self.left, self.right, self.height = student, None, None, 1

class AVL:
    def __init__(self): self.root = None

    def _h(self, n): return n.height if n else 0
    def _update(self, n): n.height = 1 + max(self._h(n.left), self._h(n.right))
    def _balance(self, n): return self._h(n.left) - self._h(n.right)

    def _rotate_right(self, y):
        x, t2 = y.left, y.left.right
        x.right, y.left = y, t2
        self._update(y); self._update(x); return x

    def _rotate_left(self, x):
        y, t2 = x.right, x.right.left
        y.left, x.right = x, t2
        self._update(x); self._update(y); return y

    def _insert(self, node, student):
        if node is None: return AVLNode(student)
        key = student.register_no
        if key < node.student.register_no: node.left = self._insert(node.left, student)
        elif key > node.student.register_no: node.right = self._insert(node.right, student)
        else: raise ValueError("Duplicate register number")
        self._update(node)
        balance = self._balance(node)
        if balance > 1 and key < node.left.student.register_no: return self._rotate_right(node)  # LL
        if balance < -1 and key > node.right.student.register_no: return self._rotate_left(node) # RR
        if balance > 1 and key > node.left.student.register_no: # LR
            node.left = self._rotate_left(node.left); return self._rotate_right(node)
        if balance < -1 and key < node.right.student.register_no: # RL
            node.right = self._rotate_right(node.right); return self._rotate_left(node)
        return node

    def insert(self, student): self.root = self._insert(self.root, student)

    def search(self, key):
        cur, comparisons = self.root, 0
        while cur:
            comparisons += 1
            if key == cur.student.register_no: return cur.student, comparisons
            cur = cur.left if key < cur.student.register_no else cur.right
        return None, comparisons

    def height(self):
        def h(n):
            if n is None: return -1
            return 1 + max(h(n.left), h(n.right))
        return h(self.root)

    def inorder(self):
        out = []
        def walk(n):
            if n:
                walk(n.left); out.append(n.student.register_no); walk(n.right)
        walk(self.root); return out

class LinearProbingHash:
    """Table size is chosen above the dataset size to keep load factor moderate."""
    def __init__(self, capacity=67):
        self.capacity = capacity
        self.table = [None] * capacity
        self.collisions = 0

    def _index(self, key): return key % self.capacity

    def insert(self, student):
        index = self._index(student.register_no)
        for _ in range(self.capacity):
            if self.table[index] is None:
                self.table[index] = student; return
            if self.table[index].register_no == student.register_no:
                raise ValueError("Duplicate register number")
            self.collisions += 1
            index = (index + 1) % self.capacity
        raise OverflowError("Hash table is full")

    def search(self, key):
        index, comparisons = self._index(key), 0
        for _ in range(self.capacity):
            comparisons += 1
            item = self.table[index]
            if item is None: return None, comparisons
            if item.register_no == key: return item, comparisons
            index = (index + 1) % self.capacity
        return None, comparisons

def run_experiment():
    records = load_students()
    # Fixed shuffle gives reproducible insertion order without arranging keys in sorted order.
    insertion_order = records[:]
    random.Random(42).shuffle(insertion_order)

    bst, avl, hashing = BST(), AVL(), LinearProbingHash()
    for s in insertion_order:
        bst.insert(s); avl.insert(s); hashing.insert(s)

    successful_key = records[len(records)//2].register_no
    unsuccessful_key = 9999999
    new_student = Student(9999998, "TestInsert", "AIML", 2, 8.5)

    observations = {}
    for label, structure in [("BST", bst), ("AVL", avl), ("Hashing", hashing)]:
        found, succ_comps = structure.search(successful_key)
        missing, fail_comps = structure.search(unsuccessful_key)
        # Test insertion independently after the search measurements.
        structure.insert(new_student)
        inserted, insert_comps = structure.search(new_student.register_no)
        observations[label] = {
            "successful_search_key": successful_key,
            "successful_search_found": found is not None,
            "successful_search_comparisons": succ_comps,
            "unsuccessful_search_key": unsuccessful_key,
            "unsuccessful_search_found": missing is not None,
            "unsuccessful_search_comparisons": fail_comps,
            "new_record_inserted_and_verified": inserted is not None,
            "insertion_verification_comparisons": insert_comps,
            "height_edges": structure.height() if label in ("BST", "AVL") else "N/A",
            "hash_collisions_during_initial_dataset_insertion":
                hashing.collisions if label == "Hashing" else "N/A"
        }

    RESULTS_DIR.mkdir(exist_ok=True)
    (RESULTS_DIR / "experiment_results.json").write_text(
        json.dumps(observations, indent=2), encoding="utf-8")
    print("DATA STRUCTURE EXPERIMENT RESULTS")
    print("Dataset records:", len(records))
    print("Insertion order: shuffled using fixed seed 42")
    print("Tree height is measured in edges (leaf = 0; empty tree = -1).")
    print(json.dumps(observations, indent=2))
    print("\nBST inorder traversal:", bst.inorder())
    print("BST preorder traversal:", bst.preorder())
    print("BST postorder traversal:", bst.postorder())
    print("AVL inorder traversal:", avl.inorder())
    print("\nSaved results to results/experiment_results.json")

if __name__ == "__main__":
    run_experiment()
