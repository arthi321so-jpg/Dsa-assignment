# DSA CLA-2 — Algorithm Battle: Which Data Structure Wins?

**Student Name:** Arthi B  
**Register Number:** RA2511026050290  
**Institution:** SRM Institute of Science and Technology, Tiruchirappalli  
**Application:** Student Record Search System

## Part A — Problem Selection
The application stores student details and searches for a student using a unique register number. Efficient searching is important because a college may store many records and users need to retrieve a record quickly. BST, AVL, and hashing are suitable for comparison because they organize the same keys differently and have different search, insertion, and memory behaviours.

## Part B — Implementation
- **BST:** ordered binary tree; smaller keys go left and larger keys go right.
- **AVL:** self-balancing BST; rotations maintain the balance condition.
- **Hashing:** register number is mapped using `key % table_capacity`; collisions are handled using linear probing.

## Part C — Dataset and Mini Experiment
Dataset size: 40 sample records in `data/students.csv`.  
Insertion order: shuffled with fixed seed 42 for repeatability.

Run `python src/main.py` and paste the actual output below.

### Experimental observations
| Parameter | BST | AVL | Hashing |
|---|---:|---:|---:|
| Successful search comparisons | [fill from output] | [fill from output] | [fill from output] |
| Unsuccessful search comparisons | [fill from output] | [fill from output] | [fill from output] |
| Height (edges) | [fill from output] | [fill from output] | N/A |
| Collisions during dataset insertion | N/A | N/A | [fill from output] |
| New record inserted and verified | [yes/no] | [yes/no] | [yes/no] |

### Insertion observations
Describe what happened when register number `9999998` was inserted into each structure. Mention the AVL rotation(s), if any, only if you verify them from your implementation or explain the balancing logic.

## Part D — Algorithm Battle
Compare the measured search comparisons, tree heights, and hash collisions. Explain that the results depend on insertion order, hash function, table capacity, and dataset size.

## Part E — Final Verdict
**Winner:** [choose after examining your measured results]

**Justification:** [Use your actual observations. For example, discuss whether hashing used fewer comparisons in these tests, whether AVL maintained a smaller height than BST, and the trade-off of collision handling.]

## Viva preparation
1. What is a BST and how does it search?
2. Why can a BST become skewed?
3. What is the AVL balance factor?
4. Name the four AVL rotations: LL, RR, LR, RL.
5. What is a hash function?
6. What is a collision?
7. How does linear probing resolve a collision?
8. What is the difference between successful and unsuccessful search?
9. Why must all three structures use the same dataset?
10. Why can experimental results change with insertion order or hash-table size?

## Submission checklist
- [ ] Run the Python program.
- [ ] Check `results/experiment_results.json`.
- [ ] Fill the report table using actual output.
- [ ] Write the final verdict based on your observations.
- [ ] Upload the source code, CSV dataset, results, and README to GitHub.
- [ ] Submit the GitHub repository URL and required report through Google Classroom.
