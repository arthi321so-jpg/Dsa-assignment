# Student Record Search System — DSA CLA-2

**Student Name:** Arthi B  
**Register Number:** RA2511026050290  
**Institution:** SRM Institute of Science and Technology, Tiruchirappalli

## Application
This project compares three ways to store and search student records by unique register number:
1. Binary Search Tree (BST)
2. AVL Tree
3. Hashing with Linear Probing

Each record stores register number, name, department, year, and CGPA. The included dataset has 40 sample records. These are demonstration records, not official student data.

## Requirements
- Python 3.9 or newer
- No third-party packages required

## Run
From the project folder:

```bash
python src/main.py
```

The program:
- Loads the same CSV dataset into all three structures.
- Uses a reproducible shuffled insertion order (seed 42).
- Runs one successful and one unsuccessful search.
- Counts key comparisons.
- Measures BST and AVL height in edges.
- Counts collisions during the initial hash-table dataset insertion.
- Inserts and verifies one additional record.
- Prints BST traversals and AVL inorder traversal.
- Saves measured output to `results/experiment_results.json`.

## Measurement definitions
- **Search comparison:** one comparison of the search key with a stored register number.
- **Tree height:** number of edges on the longest root-to-leaf path; a leaf has height 0.
- **Hash collision:** an occupied slot encountered while inserting a new key, before finding an empty slot.
- **Unsuccessful search:** search for key `9999999`, which is not in the dataset.
- **Insertion test:** adds register number `9999998` after the search tests.

## Important academic note
Run the program yourself and use the generated JSON output as your experimental observations. Do not copy example/fabricated measurements. Explain the chosen hash function (`key % capacity`), linear probing, AVL rotations, and BST traversal during your viva.

## Suggested GitHub repository contents
Keep `src/`, `data/`, `results/`, and this README in your repository. After running the program, commit the generated `experiment_results.json`.
